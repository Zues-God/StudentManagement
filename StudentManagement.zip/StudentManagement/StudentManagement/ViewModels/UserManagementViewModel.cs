﻿using StudentManagement.Helper;
using StudentManagement.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;

namespace StudentManagement.ViewModels
{
    internal class UserManagementViewModel : BaseViewModel
    {
        private User user;
        public User User
        {
            get { return user; }
            set { user = value; OnPropertyChanged(nameof(User)); }
        }
        private ObservableCollection<User> users;
        public ObservableCollection<User> Users
        {
            get { return users; }
            set { users = value; OnPropertyChanged(nameof(Users)); }
        }
        private User _selectedUser;
        public User SelectedUser
        {
            get { return _selectedUser; }
            set
            {
                _selectedUser = value;
                if (_selectedUser != null)
                {
                    // Tạo bản sao để edit mà không ảnh hưởng SelectedUser trực tiếp
                    EditedUser = new User
                    {
                        Id = _selectedUser.Id,
                        Username = _selectedUser.Username,
                        Password = _selectedUser.Password,
                        Email = _selectedUser.Email,
                        FullName = _selectedUser.FullName,
                        DateOfBirth = _selectedUser.DateOfBirth,
                        Phone = _selectedUser.Phone,
                        Address = _selectedUser.Address,
                        Role = _selectedUser.Role,
                        IsActive = _selectedUser.IsActive
                    };
                }
                else
                {
                    EditedUser = null;
                }
                OnPropertyChanged(nameof(SelectedUser));
            }
        }
        private User _editedUser;
        public User EditedUser
        {
            get { return _editedUser; }
            set
            {
                _editedUser = value;
                OnPropertyChanged(nameof(EditedUser));
            }
        }
        private ObservableCollection<string> roles = new ObservableCollection<string> { "student", "lecturer" };
        public ObservableCollection<string> Roles
        {
            get { return roles; }
            set { roles = value; OnPropertyChanged(nameof(Roles)); }
        }
        private ObservableCollection<bool> statuses = new ObservableCollection<bool> { true, false };
        public ObservableCollection<bool> Statuses
        {
            get { return statuses; }
            set { statuses = value; OnPropertyChanged(nameof(Statuses)); }
        }
        public ObservableCollection<bool> StatusOptions
        {
            get { return statuses; }
            set { statuses = value; OnPropertyChanged(nameof(StatusOptions)); }
        }
        private string _searchText;
        public string SearchText
        {
            get { return _searchText; }
            set
            {
                _searchText = value;
                OnPropertyChanged(nameof(SearchText));

            }
        }
        public ICommand SearchCommand => new RelayCommand(o => SearchUsers());
        public ICommand AddUserCommand { get; }
        public ICommand EditUserCommand { get; }
        public ICommand DeleteUserCommand { get; }
        public UserManagementViewModel()
        {
            LoadUsers();
            AddUserCommand = new RelayCommand(o => AddUser());
            EditUserCommand = new RelayCommand(o => EditUser(), o => SelectedUser != null);
            DeleteUserCommand = new RelayCommand(o => DeleteUser(), o => SelectedUser != null);
        }

        private void LoadUsers()
        {
            using (var context = new AppDbContext())
            {
                var userList = context.Users.ToList();
                Users = new ObservableCollection<User>(userList);
                OnPropertyChanged(nameof(Users));
            }
        }

        private void AddUser()
        {
            if (EditedUser == null)
            {
                MessageBox.Show("Select any user to start adding!", "Notification", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (EditedUser.Role != "student" && EditedUser.Role != "lecturer")
            {
                MessageBox.Show("Role must be either 'student' or 'lecturer'!", "Notification", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrEmpty(EditedUser.Username) || string.IsNullOrEmpty(EditedUser.Password) ||
                string.IsNullOrEmpty(EditedUser.Email) || string.IsNullOrEmpty(EditedUser.FullName))
            {
                MessageBox.Show("Please fill in all required information!", "Notification", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!UtilClass.IsValidUsername(EditedUser.Username))
            {
                MessageBox.Show("Username must start with a letter. The following 2 to 15 characters can be letters, numbers, or underscores!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!UtilClass.IsValidPassword(EditedUser.Password))
            {
                MessageBox.Show("Password Must be at least 8 characters, at least 1 uppercase letter, 1 lowercase letter, 1 number and 1 special character!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!UtilClass.IsValidEmail(EditedUser.Email))
            {
                MessageBox.Show("Invalid email!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!UtilClass.IsValidFullName(EditedUser.FullName))
            {
                MessageBox.Show("Full name: only letters and spaces allowed, minimum 2 words!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!string.IsNullOrEmpty(EditedUser.Phone) && !UtilClass.IsValidPhone(EditedUser.Phone))
            {
                MessageBox.Show("Phone number: starts with 0, has 10 or 11 digits!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!string.IsNullOrEmpty(EditedUser.Address) && !UtilClass.IsValidAddress(EditedUser.Address))
            {
                MessageBox.Show("Address: allows letters, numbers, commas, periods, spaces, minimum 5 characters!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            EditedUser.Username = EditedUser.Username ?? "";
            EditedUser.Password = EditedUser.Password ?? "";
            EditedUser.Email = EditedUser.Email ?? "";
            EditedUser.FullName = EditedUser.FullName ?? "";
            EditedUser.Phone = EditedUser.Phone ?? "";
            EditedUser.Address = EditedUser.Address ?? "";
            User user = new User(EditedUser.Username, EditedUser.Password, EditedUser.Email, EditedUser.Role, EditedUser.FullName, EditedUser.DateOfBirth, EditedUser.Phone, EditedUser.Address);

            using (var db = new AppDbContext())
            {
                if (db.Users.Any(u => u.Username == EditedUser.Username))
                {
                    MessageBox.Show("Username already exists!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                if (db.Users.Any(u => u.Email == EditedUser.Email))
                {
                    MessageBox.Show("Email already exists!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                using (var context = new AppDbContext())
                {
                    EditedUser.Id = 0;
                    context.Users.Add(EditedUser);
                    context.SaveChanges();
                    LoadUsers();
                }
            }
        }

        private void EditUser()
        {
            if (EditedUser == null)
            {
                MessageBox.Show("Please select user to edit!", "Notification", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (EditedUser.Id == 0)
            {
                MessageBox.Show("You cannot perform this action on the selected user!", "Notification", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrEmpty(EditedUser.Username) ||
                string.IsNullOrEmpty(EditedUser.Email) || string.IsNullOrEmpty(EditedUser.FullName))
            {
                MessageBox.Show("Please fill in all required information!", "Notification", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!UtilClass.IsValidUsername(EditedUser.Username))
            {
                MessageBox.Show("Username must start with a letter. The following 2 to 15 characters can be letters, numbers, or underscores!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!UtilClass.IsValidEmail(EditedUser.Email))
            {
                MessageBox.Show("Invalid email!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!UtilClass.IsValidFullName(EditedUser.FullName))
            {
                MessageBox.Show("Full name: only letters and spaces allowed, minimum 2 words!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!string.IsNullOrEmpty(EditedUser.Phone) && !UtilClass.IsValidPhone(EditedUser.Phone))
            {
                MessageBox.Show("Phone number: starts with 0, has 10 or 11 digits!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!string.IsNullOrEmpty(EditedUser.Address) && !UtilClass.IsValidAddress(EditedUser.Address))
            {
                MessageBox.Show("Address: allows letters, numbers, commas, periods, spaces, minimum 5 characters!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

                
                using (var context = new AppDbContext())
            {
                    if (SelectedUser.Username != EditedUser.Username && context.Users.Any(u => u.Username == EditedUser.Username))
                    {
                        MessageBox.Show("Username already exists!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }
                    if (SelectedUser.Email != EditedUser.Email && context.Users.Any(u => u.Email == EditedUser.Email))
                    {
                        MessageBox.Show("Email already exists!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }
                    var userInDb = context.Users.Find(EditedUser.Id);
                if (userInDb != null)
                {
                    userInDb.Username = EditedUser.Username;
                    userInDb.Password = EditedUser.Password;
                    userInDb.Email = EditedUser.Email;
                    userInDb.FullName = EditedUser.FullName;
                    userInDb.DateOfBirth = EditedUser.DateOfBirth;
                    userInDb.Phone = EditedUser.Phone;
                    userInDb.Address = EditedUser.Address;
                    userInDb.Role = EditedUser.Role;
                    userInDb.IsActive = EditedUser.IsActive;
                    context.SaveChanges();
                    LoadUsers();
                }
            }
        }

        private void DeleteUser()
        {
            if (EditedUser == null)
            {
                MessageBox.Show("Please select user before delete!", "Notification", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (EditedUser.Id == 0)
            {
                MessageBox.Show("You cannot perform this action on the selected user!", "Notification", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            using (var context = new AppDbContext())
            {
                var userInDb = context.Users.Find(SelectedUser.Id);
                if (userInDb != null)
                {
                    context.Users.Remove(userInDb);
                    context.SaveChanges();
                    LoadUsers();
                }
            }
        }


        private void SearchUsers()
        {
            using (var context = new AppDbContext())
            {
                var query = context.Users.AsQueryable();
                if (!string.IsNullOrWhiteSpace(SearchText))
                {
                    query = query.Where(u => u.Username.Contains(SearchText));
                }
                var filteredUsers = query.ToList();
                Users = new ObservableCollection<User>(filteredUsers);
                OnPropertyChanged(nameof(Users));
            }
        }
    }
}
